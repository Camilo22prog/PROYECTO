import java.awt.Color;

/**
 * Robot.java - Robot que se desplaza por la ruta y recolecta dinero.
 * Versión corregida con ID único y tracking de ganancias.
 * @author MELO-ROZO  
 * @version CICLO-COMPLETO
 */
public class Robot {
    private final int id;
    private int location;
    private final int initLocation;
    private final Color color;
    private int collectedMoney;  // Nuevo: tracking de dinero recolectado
    
    public Robot(int id, int location) {
        this.id = id;
        this.location = location;
        this.initLocation = location;
        this.collectedMoney = 0;
        this.color = generateColorFromId(id);
    }
    
    // Constructor para compatibilidad con código existente
    public Robot(int location) {
        this(getNextId(), location);
    }
    
    // Métodos originales
    public int getLocation() { return location; }
    public Color getColor() { return color; }
    
    public void move(int meters) { 
        location += meters; 
    }
    
    public void reset() { 
        location = initLocation;
        // Nota: collectedMoney NO se resetea aquí, solo en reboot completo
    }
    
    // Nuevos métodos
    public int getId() { return id; }
    public int getInitLocation() { return initLocation; }
    public int getCollectedMoney() { return collectedMoney; }
    
    /**
     * Registra dinero recolectado por este robot
     */
    public void addMoney(int amount) {
        collectedMoney += amount;
    }
    
    /**
     * Resetea las ganancias del robot (para reboot completo)
     */
    public void resetMoney() {
        collectedMoney = 0;
    }
    
    /**
     * Mueve el robot a una ubicación específica
     */
    public void moveTo(int newLocation) {
        location = newLocation;
    }
    
    /**
     * Genera color único basado en ID del robot
     */
    private Color generateColorFromId(int robotId) {
        // Colores predefinidos para robots
        Color[] robotColors = {
            Color.getHSBColor(0.55f, 1f, 0.9f), // azul cian (original)
            Color.RED,
            Color.BLACK,
            new Color(0, 100, 0),    // Verde oscuro
            new Color(139, 69, 19),  // Marrón
            new Color(75, 0, 130),   // Índigo
            Color.ORANGE,
            Color.PINK,
            new Color(128, 0, 128),  // Púrpura
            new Color(0, 128, 128)   // Teal
        };
        
        return robotColors[robotId % robotColors.length];
    }
    
    /**
     * Contador estático para IDs únicos
     */
    private static int nextId = 0;
    private static int getNextId() {
        return nextId++;
    }
    
    /**
     * Resetea el contador de IDs (para testing)
     */
    public static void resetIdCounter() {
        nextId = 0;
    }
    
    /**
     * Obtiene información de estado para debugging
     */
    public String getStatus() {
        return "Robot[id=" + id + ", location=" + location + 
               ", initLocation=" + initLocation + ", money=" + collectedMoney + "]";
    }
    
    @Override
    public String toString() {
        return getStatus();
    }
}