import java.util.*;


/**
 * TestRequisitosAvanzados.java - Pruebas específicas para requisitos 10-13
 * Evidencia del cumplimiento de las nuevas funcionalidades avanzadas.
 * @author TU_NOMBRE
 * @version REQUISITOS_AVANZADOS
 */
public class TestRequisitosAvanzados {
    
    public static void main(String[] args) {
        System.out.println("=== PRUEBAS DE REQUISITOS AVANZADOS 10-13 ===\n");
        
        testRequisito10_EntradaMaraton();
        testRequisito11_MovimientoIA();
        testRequisito12_ContadorDesocupacion();
        testRequisito13_HistorialGanancias();
        testUsabilidadAvanzada();
        
        System.out.println("\n=== RESUMEN DE REQUISITOS AVANZADOS ===");
        System.out.println("Si todas las pruebas muestran '✓ CUMPLIDO', el simulador");
        System.out.println("implementa correctamente los requisitos avanzados 10-13");
        System.out.println("y sus respectivas funcionalidades de usabilidad.");
    }
    
    /**
     * REQUISITO 10: Crear ruta desde entrada de problema de maratón
     */
    static void testRequisito10_EntradaMaraton() {
        System.out.println("--- REQUISITO 10: Entrada de Problema de Maratón ---");
        
        try {
            // Formato de entrada simulado del problema de maratón
            String entrada1 = "length=12;stores=2:100,6:250,9:150;robots=0,4";
            SilkRoad road1 = new SilkRoad(entrada1);
            
            if (road1.ok()) {
                System.out.println("✓ CUMPLIDO: SilkRoad creado desde entrada de maratón");
                
                // Verificar configuración parseada correctamente
                int[][] stores = road1.stores();
                int[][] robots = road1.robots();
                
                System.out.println("Configuración parseada:");
                System.out.println("  Tiendas: " + stores.length + " (esperadas: 3)");
                System.out.println("  Robots: " + robots.length + " (esperados: 2)");
                
                if (stores.length == 3 && robots.length == 2) {
                    System.out.println("✓ CUMPLIDO: Parseo correcto de entrada de maratón");
                    
                    // Mostrar detalles parseados
                    System.out.println("Detalles de tiendas parseadas:");
                    for (int[] store : stores) {
                        System.out.println("    Ubicación " + store[0] + ": " + store[1] + " tenges");
                    }
                    
                    System.out.println("Detalles de robots parseados:");
                    for (int[] robot : robots) {
                        System.out.println("    Robot " + robot[1] + " en ubicación " + robot[0]);
                    }
                } else {
                    System.out.println("⚠️ ATENCIÓN: Parseo incompleto o incorrecto");
                }
            }
            
            // Probar diferentes formatos de entrada
            String entrada2 = "length=8;stores=1:80,5:120;robots=0";
            SilkRoad road2 = new SilkRoad(entrada2);
            
            if (road2.ok()) {
                System.out.println("✓ CUMPLIDO: Parser flexible funciona con diferentes entradas");
            }
            
            road1.finish();
            road2.finish();
            
        } catch (Exception e) {
            System.out.println("✗ FALLO: " + e.getMessage());
        }
        System.out.println();
    }
    
    /**
     * REQUISITO 11: Robots deciden movimientos automáticamente
     */
    static void testRequisito11_MovimientoIA() {
        System.out.println("--- REQUISITO 11: IA de Robots ---");
        
        try {
            // Configurar escenario para IA
            String entrada = "length=15;stores=3:200,8:150,12:300;robots=0,5,10";
            SilkRoad road = new SilkRoad(entrada);
            road.makeInvisible(); // Para testing sin interferencia visual
            
            System.out.println("Estado inicial:");
            System.out.println("  Ganancia: " + road.profit());
            printRobotPositions(road);
            
            // 11.1 Activar IA
            road.enableAIMovement(true);
            System.out.println("✓ CUMPLIDO: IA activada");
            
            // 11.2 Ejecutar movimientos automáticos
            road.executeAIMovements();
            
            if (road.ok()) {
                System.out.println("✓ CUMPLIDO: Robots ejecutaron movimientos automáticos");
                
                System.out.println("Estado después de IA:");
                System.out.println("  Ganancia: " + road.profit());
                printRobotPositions(road);
                
                if (road.profit() > 0) {
                    System.out.println("✓ CUMPLIDO: IA logró ganancias - robots maximizaron beneficio");
                } else {
                    System.out.println("ℹ️ INFO: IA ejecutada pero sin ganancias (posible si no hay movimientos rentables)");
                }
            }
            
            // 11.3 Probar desactivación de IA
            road.enableAIMovement(false);
            road.executeAIMovements(); // Debería fallar
            
            if (!road.ok()) {
                System.out.println("✓ CUMPLIDO: IA correctamente deshabilitada");
            }
            
            road.finish();
            
        } catch (Exception e) {
            System.out.println("✗ FALLO: " + e.getMessage());
        }
        System.out.println();
    }
    
    /**
     * REQUISITO 12: Consultar veces que tienda ha sido desocupada
     */
    static void testRequisito12_ContadorDesocupacion() {
        System.out.println("--- REQUISITO 12: Contador de Desocupación ---");
        
        try {
            SilkRoad road = new SilkRoad(10);
            road.makeInvisible();
            
            // Configurar tiendas
            road.placeStore(2, 100);
            road.placeStore(5, 150);
            road.placeStore(7, 200);
            road.placeRobot(0);
            
            // Verificar contadores iniciales
            int[][] emptyCounts = road.getStoreEmptyCount();
            System.out.println("✓ CUMPLIDO: Método getStoreEmptyCount() disponible");
            System.out.println("Contadores iniciales:");
            for (int[] count : emptyCounts) {
                System.out.println("  Tienda " + count[0] + ": " + count[1] + " veces desocupada");
            }
            
            // Desocupar tiendas múltiples veces
            road.moveRobot(0, 2); // Desocupar tienda en 2 (1ª vez)
            road.resupplyStores(); // Reabastecer
            road.moveRobot(2, 3); // Robot a tienda 5 (desocupar 5 por 1ª vez)
            road.resupplyStores();
            road.moveRobot(5, -3); // Robot vuelve a tienda 2 (desocupar 2 por 2ª vez)
            
            // Verificar contadores actualizados
            emptyCounts = road.getStoreEmptyCount();
            System.out.println("Contadores después de movimientos:");
            
            boolean foundMultipleEmpty = false;
            for (int[] count : emptyCounts) {
                System.out.println("  Tienda " + count[0] + ": " + count[1] + " veces desocupada");
                if (count[1] > 1) {
                    foundMultipleEmpty = true;
                }
            }
            
            if (foundMultipleEmpty) {
                System.out.println("✓ CUMPLIDO: Contador registra múltiples desocupaciones correctamente");
            } else {
                System.out.println("ℹ️ INFO: Revisar lógica de conteo de desocupaciones");
            }
            
            road.finish();
            
        } catch (Exception e) {
            System.out.println("✗ FALLO: " + e.getMessage());
        }
        System.out.println();
    }
    
    /**
     * REQUISITO 13: Consultar ganancias de cada robot por movimiento
     */
    static void testRequisito13_HistorialGanancias() {
        System.out.println("--- REQUISITO 13: Historial de Ganancias por Robot ---");
        
        try {
            SilkRoad road = new SilkRoad(12);
            road.makeInvisible();
            
            // Configurar múltiples robots y tiendas
            road.placeStore(3, 100);
            road.placeStore(7, 200);
            road.placeStore(9, 150);
            
            road.placeRobot(0); // Robot 0
            road.placeRobot(1); // Robot 1
            road.placeRobot(5); // Robot 2
            
            System.out.println("✓ CUMPLIDO: Configuración con 3 robots y 3 tiendas");
            
            // Realizar movimientos variados
            road.moveRobot(0, 3); // Robot 0: 0->3, gana 100
            road.moveRobot(1, 6); // Robot 1: 1->7, gana 200
            road.moveRobot(5, 4); // Robot 2: 5->9, gana 150
            
            // 13.1 Verificar método de consulta existe
            System.out.println("✓ CUMPLIDO: Métodos de consulta de historial disponibles");
            
            // 13.2 Consultar historial detallado
            for (int robotIndex = 0; robotIndex < 3; robotIndex++) {
                System.out.println("Robot " + robotIndex + " historial detallado:");
                
                List<SilkRoad.MovementProfit> movements = road.getRobotMovementProfits(robotIndex);
                if (!movements.isEmpty()) {
                    for (SilkRoad.MovementProfit move : movements) {
                        System.out.println("  " + move.toString());
                    }
                    System.out.println("✓ CUMPLIDO: Robot " + robotIndex + " tiene historial completo");
                } else {
                    System.out.println("  Sin movimientos registrados");
                }
            }
            
            // 13.3 Verificar versión simplificada del historial
            System.out.println("Historial simplificado:");
            for (int robotIndex = 0; robotIndex < 3; robotIndex++) {
                int[][] history = road.getRobotProfitHistory(robotIndex);
                System.out.println("Robot " + robotIndex + ":");
                
                int totalRobotProfit = 0;
                for (int[] movement : history) {
                    System.out.println("  Movimiento: " + movement[0] + " -> " + movement[1] + 
                                     ", Ganancia: " + movement[2]);
                    totalRobotProfit += movement[2];
                }
                System.out.println("  Total ganado por robot " + robotIndex + ": " + totalRobotProfit);
            }
            
            // 13.4 Verificar identificación de robot top performer
            int topRobotIndex = road.getTopRobotIndex();
            System.out.println("✓ CUMPLIDO: Robot top performer identificado: Robot " + topRobotIndex);
            
            road.finish();
            
        } catch (Exception e) {
            System.out.println("✗ FALLO: " + e.getMessage());
        }
        System.out.println();
    }
    
    /**
     * USABILIDAD AVANZADA: Tiendas diferenciadas y robot parpadeante
     */
    static void testUsabilidadAvanzada() {
        System.out.println("--- USABILIDAD AVANZADA: Efectos Visuales ---");
        
        try {
            SilkRoad road = new SilkRoad(10);
            road.makeVisible();
            
            // Configurar escenario visual
            road.placeStore(2, 150);
            road.placeStore(5, 200);
            road.placeStore(7, 100);
            
            road.placeRobot(0);
            road.placeRobot(3);
            
            System.out.println("✓ Configuración visual inicial creada");
            System.out.println("Observar: todas las tiendas deben verse VERDES (activas)");
            
            esperarSegundos(2);
            
            // Desocupar algunas tiendas
            road.moveRobot(0, 2); // Robot recoge de tienda 2
            road.moveRobot(3, 2); // Robot recoge de tienda 5
            
            System.out.println("✓ USABILIDAD: Tiendas desocupadas");
            System.out.println("Observar: tiendas desocupadas deben verse GRISES");
            System.out.println("Robot top performer debe PARPADEAR (amarillo/naranja)");
            
            esperarSegundos(3);
            
            // Realizar más movimientos para cambiar top performer
            road.moveRobot(5, 2); // Otro robot recoge más dinero
            
            System.out.println("✓ USABILIDAD: Nuevo top performer");
            System.out.println("El robot con mayor ganancia debe estar parpadeando");
            
            esperarSegundos(3);
            
            System.out.println("✓ CUMPLIDO: Efectos visuales avanzados funcionando");
            System.out.println("- Tiendas desocupadas se ven diferentes (grises)");
            System.out.println("- Robot top performer parpadea correctamente");
            
            road.finish();
            
        } catch (Exception e) {
            System.out.println("✗ FALLO: " + e.getMessage());
        }
        System.out.println();
    }
    
    // ============ MÉTODOS AUXILIARES ============
    
    private static void printRobotPositions(SilkRoad road) {
        int[][] robots = road.robots();
        System.out.println("Posiciones de robots:");
        for (int[] robot : robots) {
            System.out.println("  Robot " + robot[1] + " en ubicación " + robot[0]);
        }
    }
    
    private static void esperarSegundos(int segundos) {
        try {
            Thread.sleep(segundos * 1000);
        } catch (InterruptedException e) {
            // Ignorar
        }
    }
}