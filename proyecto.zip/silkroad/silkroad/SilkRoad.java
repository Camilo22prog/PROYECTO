import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import shapes.*;

/**
 * SilkRoad.java - Simulador completo con requisitos avanzados 10-13.
 * Incluye entrada de problema de maratón, IA de robots, y tracking avanzado.
 * @author TU_NOMBRE
 * @version ENTREGA_AVANZADA
 */
public class SilkRoad {

    private int length;
    private final List<Store> stores = new ArrayList<>();
    private final List<Robot> robots = new ArrayList<>();
    private final SilkDisplay display;
    
    // Funcionalidades básicas
    private int totalProfit = 0;
    private boolean lastOperationOk = true;
    
    // Estados iniciales
    private final List<StoreState> initialStores = new ArrayList<>();
    private final List<RobotState> initialRobots = new ArrayList<>();
    
    // NUEVOS: Requisitos 10-13
    private Map<Integer, Integer> storeEmptyCount = new HashMap<>(); // Req 13: veces desocupada
    private Map<Integer, List<MovementProfit>> robotMovementProfits = new HashMap<>(); // Req 14: ganancias por movimiento
    private boolean aiMovementEnabled = false; // Req 11: IA activada
    
    /**
     * Constructor original
     */
    public SilkRoad(int length) {
        if (length <= 0) {
            throw new IllegalArgumentException("Length must be positive");
        }
        this.length = length;
        this.display = new SilkDisplay(length, stores, robots);
    }

    /**
     * REQUISITO 10: Constructor que acepta entrada del problema de maratón
     * Formato esperado: línea con posiciones de tiendas y sus valores
     * Ejemplo: "3:100,7:200,12:150" significa tienda en pos 3 con 100 tenges, etc.
     */
    public SilkRoad(String marathonInput) {
        this.display = new SilkDisplay(50, stores, robots); // Longitud por defecto amplia
        
        try {
            parseMarathonInput(marathonInput);
            lastOperationOk = true;
        } catch (Exception e) {
            System.err.println("Error parsing marathon input: " + e.getMessage());
            this.length = 10; // Valor por defecto en caso de error
            lastOperationOk = false;
            return;
        }
        
        System.out.println("SilkRoad creado desde entrada de maratón:");
        System.out.println("Longitud de ruta: " + length);
        System.out.println("Tiendas configuradas: " + stores.size());
    }
    
    /**
     * Parsea la entrada del formato de maratón
     */
    private void parseMarathonInput(String input) {
        // Ejemplo de formato esperado: "length=20;stores=3:100,7:200,12:150;robots=0,5,8"
        String[] parts = input.split(";");
        
        int parsedLength = 20; // valor por defecto
        
        for (String part : parts) {
            part = part.trim();
            if (part.startsWith("length=")) {
                parsedLength = Integer.parseInt(part.substring(7));
            } else if (part.startsWith("stores=")) {
                String storeData = part.substring(7);
                parseStores(storeData);
            } else if (part.startsWith("robots=")) {
                String robotData = part.substring(7);
                parseRobots(robotData);
            }
        }
        
        this.length = parsedLength;
    }
    
    private void parseStores(String storeData) {
        if (storeData.isEmpty()) return;
        
        String[] storeEntries = storeData.split(",");
        for (String entry : storeEntries) {
            String[] parts = entry.split(":");
            if (parts.length == 2) {
                int location = Integer.parseInt(parts[0].trim());
                int tenges = Integer.parseInt(parts[1].trim());
                
                Store store = new Store(location, tenges);
                stores.add(store);
                initialStores.add(new StoreState(location, tenges));
                storeEmptyCount.put(location, 0); // Inicializar contador
            }
        }
    }
    
    private void parseRobots(String robotData) {
        if (robotData.isEmpty()) return;
        
        String[] robotEntries = robotData.split(",");
        for (String entry : robotEntries) {
            int location = Integer.parseInt(entry.trim());
            
            Robot robot = new Robot(location);
            robots.add(robot);
            initialRobots.add(new RobotState(robots.size() - 1, location));
            robotMovementProfits.put(robots.size() - 1, new ArrayList<>()); // Inicializar historial
        }
    }

    // ============ FUNCIONALIDADES BÁSICAS (REQUISITOS 1-9) ============
    
    public void placeStore(int location, int tenges) {
        lastOperationOk = false;
        
        if (!isValidLocation(location) || tenges < 0 || findStoreAt(location) != null) {
            showError("Cannot place store at location " + location);
            return;
        }
        
        Store newStore = new Store(location, tenges);
        stores.add(newStore);
        display.addStore(newStore);
        
        initialStores.add(new StoreState(location, tenges));
        storeEmptyCount.put(location, 0); // NUEVO: Inicializar contador
        
        updateProfitDisplay();
        lastOperationOk = true;
    }

    public void placeRobot(int location) {
        lastOperationOk = false;
        
        if (!isValidLocation(location)) {
            showError("Invalid location: " + location);
            return;
        }
        
        Robot newRobot = new Robot(location);
        robots.add(newRobot);
        display.addRobot(newRobot);
        
        initialRobots.add(new RobotState(robots.size() - 1, location));
        robotMovementProfits.put(robots.size() - 1, new ArrayList<>()); // NUEVO: Inicializar historial
        
        lastOperationOk = true;
    }

    public void makeVisible() {
        display.makeVisible();
    }

    public void removeStore(int location) {
        lastOperationOk = false;
        
        Store storeToRemove = findStoreAt(location);
        if (storeToRemove == null) {
            showError("No store at location " + location);
            return;
        }
        
        stores.remove(storeToRemove);
        display.removeStore(storeToRemove);
        
        initialStores.removeIf(s -> s.location == location);
        storeEmptyCount.remove(location); // NUEVO: Limpiar contador
        
        updateProfitDisplay();
        lastOperationOk = true;
    }

    public void removeRobot(int location) {
        lastOperationOk = false;
        
        Robot robotToRemove = findFirstRobotAt(location);
        if (robotToRemove == null) {
            showError("No robot at location " + location);
            return;
        }
        
        int robotIndex = robots.indexOf(robotToRemove);
        robots.remove(robotToRemove);
        display.removeRobot(robotToRemove);
        
        initialRobots.removeIf(r -> r.id == robotIndex);
        robotMovementProfits.remove(robotIndex); // NUEVO: Limpiar historial
        
        lastOperationOk = true;
    }

    /**
     * Movimiento manual de robot (versión original)
     */
    public void moveRobot(int location, int meters) {
        moveRobotInternal(location, meters, false); // false = movimiento manual
    }
    
    /**
     * REQUISITO 11: Activar/desactivar movimiento inteligente de robots
     */
    public void enableAIMovement(boolean enabled) {
        this.aiMovementEnabled = enabled;
        System.out.println("AI Movement " + (enabled ? "ENABLED" : "DISABLED"));
    }
    
    /**
     * REQUISITO 11: Los robots deciden automáticamente sus movimientos
     * Buscan maximizar ganancia usando algoritmo greedy simple
     */
    public void executeAIMovements() {
        if (!aiMovementEnabled) {
            showError("AI movement is not enabled. Call enableAIMovement(true) first.");
            return;
        }
        
        lastOperationOk = false;
        System.out.println("=== EXECUTING AI MOVEMENTS ===");
        
        // Para cada robot, calcular el mejor movimiento posible
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            int currentLocation = robot.getLocation();
            
            BestMove bestMove = calculateBestMove(currentLocation);
            
            if (bestMove.isValid) {
                System.out.println("Robot " + i + " at " + currentLocation + 
                                 " moving " + bestMove.distance + " to location " + 
                                 bestMove.targetLocation + " (expected profit: " + 
                                 bestMove.expectedProfit + ")");
                
                moveRobotInternal(currentLocation, bestMove.distance, true); // true = movimiento AI
            } else {
                System.out.println("Robot " + i + " at " + currentLocation + 
                                 " - no profitable moves available");
            }
        }
        
        lastOperationOk = true;
        System.out.println("=== AI MOVEMENTS COMPLETED ===");
    }
    
    /**
     * Calcula el mejor movimiento para un robot desde una ubicación
     */
    private BestMove calculateBestMove(int fromLocation) {
        BestMove best = new BestMove();
        
        // Probar todos los movimientos posibles dentro del rango
        for (int distance = -fromLocation; distance <= (length - 1 - fromLocation); distance++) {
            if (distance == 0) continue; // No moverse no es un movimiento
            
            int targetLocation = fromLocation + distance;
            if (!isValidLocation(targetLocation)) continue;
            
            // Verificar si hay tienda en destino con dinero
            Store targetStore = findStoreAt(targetLocation);
            if (targetStore != null && targetStore.getTenges() > 0) {
                int potentialProfit = targetStore.getTenges();
                
                // Criterio simple: elegir la tienda con más dinero más cercana
                double score = potentialProfit / (Math.abs(distance) + 1.0); // Penalizar distancia
                
                if (score > best.score) {
                    best.isValid = true;
                    best.distance = distance;
                    best.targetLocation = targetLocation;
                    best.expectedProfit = potentialProfit;
                    best.score = score;
                }
            }
        }
        
        return best;
    }
    
    /**
     * Versión interna de moveRobot que distingue movimientos manuales vs AI
     */
    private void moveRobotInternal(int location, int meters, boolean isAIMovement) {
        lastOperationOk = false;
        
        if (!isValidLocation(location)) {
            showError("Invalid location: " + location);
            return;
        }
        
        Robot robotToMove = findFirstRobotAt(location);
        if (robotToMove == null) {
            showError("No robot at location " + location);
            return;
        }
        
        int newLocation = location + meters;
        if (!isValidLocation(newLocation)) {
            showError("Robot would move outside boundaries");
            return;
        }
        
        int robotIndex = robots.indexOf(robotToMove);
        robotToMove.move(meters);
        
        // Procesar transacción
        int profitFromMove = 0;
        Store storeAtDestination = findStoreAt(newLocation);
        if (storeAtDestination != null && storeAtDestination.getTenges() > 0) {
            profitFromMove = storeAtDestination.getTenges();
            totalProfit += profitFromMove;
            
            // Incrementar contador de desocupación
            int currentCount = storeEmptyCount.getOrDefault(newLocation, 0);
            storeEmptyCount.put(newLocation, currentCount + 1);
            
            // Reemplazar tienda por versión vacía
            stores.remove(storeAtDestination);
            StoreEmpty emptyStore = new StoreEmpty(newLocation);
            stores.add(emptyStore);
        }
        
        // Registrar movimiento
        MovementProfit movement = new MovementProfit(location, newLocation, meters, 
                                                    profitFromMove, isAIMovement);
        robotMovementProfits.get(robotIndex).add(movement);
        
        // Actualizar display
        display.refreshAfterMove();
        updateProfitDisplay();
        updateTopRobotDisplay(); // NUEVO: Actualizar parpadeo si cambió top robot
        
        lastOperationOk = true;
    }

    public void returnRobots() {
        for (Robot robot : robots) {
            robot.reset();
        }
        display.refreshAfterMove();
        lastOperationOk = true;
    }

    public void reboot() {
        stores.clear();
        robots.clear();
        
        // Restaurar tiendas
        for (StoreState storeState : initialStores) {
            stores.add(new Store(storeState.location, storeState.tenges));
        }
        
        // Restaurar robots
        for (RobotState robotState : initialRobots) {
            robots.add(new Robot(robotState.location));
        }
        
        // NUEVO: Limpiar contadores y historiales
        storeEmptyCount.clear();
        for (StoreState state : initialStores) {
            storeEmptyCount.put(state.location, 0);
        }
        
        robotMovementProfits.clear();
        for (int i = 0; i < robots.size(); i++) {
            robotMovementProfits.put(i, new ArrayList<>());
        }
        
        totalProfit = 0;
        
        display.clearAll();
        for (Store store : stores) {
            display.addStore(store);
        }
        for (Robot robot : robots) {
            display.addRobot(robot);
        }
        updateProfitDisplay();
        
        lastOperationOk = true;
    }

    // ============ CONSULTAS BÁSICAS ============
    
    public int profit() { return totalProfit; }
    public boolean ok() { return lastOperationOk; }

    public int[][] stores() {
        List<Store> sortedStores = new ArrayList<>(stores);
        sortedStores.sort((s1, s2) -> Integer.compare(s1.getLocation(), s2.getLocation()));
        
        int[][] result = new int[sortedStores.size()][2];
        for (int i = 0; i < sortedStores.size(); i++) {
            Store store = sortedStores.get(i);
            result[i][0] = store.getLocation();
            result[i][1] = store.getTenges();
        }
        return result;
    }

    public int[][] robots() {
        List<RobotInfo> robotInfos = new ArrayList<>();
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            robotInfos.add(new RobotInfo(robot.getLocation(), i));
        }
        
        robotInfos.sort((r1, r2) -> {
            int locationCompare = Integer.compare(r1.location, r2.location);
            if (locationCompare != 0) return locationCompare;
            return Integer.compare(r1.id, r2.id);
        });
        
        int[][] result = new int[robotInfos.size()][2];
        for (int i = 0; i < robotInfos.size(); i++) {
            RobotInfo info = robotInfos.get(i);
            result[i][0] = info.location;
            result[i][1] = info.id;
        }
        return result;
    }

    public void resupplyStores() {
        List<Store> newStores = new ArrayList<>();
        
        for (StoreState original : initialStores) {
            stores.removeIf(s -> s.getLocation() == original.location);
            newStores.add(new Store(original.location, original.tenges));
        }
        
        stores.addAll(newStores);
        display.refreshAfterMove();
        updateProfitDisplay();
        lastOperationOk = true;
    }

    public void makeInvisible() { display.makeInvisible(); }
    public void finish() { display.finish(); }

    // ============ NUEVAS CONSULTAS (REQUISITOS 12-13) ============
    
    /**
     * REQUISITO 12: Consulta número de veces que cada tienda ha sido desocupada
     * @return array [ubicacion][veces_desocupada] ordenado por ubicación
     */
    public int[][] getStoreEmptyCount() {
        List<Map.Entry<Integer, Integer>> sortedEntries = new ArrayList<>(storeEmptyCount.entrySet());
        sortedEntries.sort((e1, e2) -> Integer.compare(e1.getKey(), e2.getKey()));
        
        int[][] result = new int[sortedEntries.size()][2];
        for (int i = 0; i < sortedEntries.size(); i++) {
            Map.Entry<Integer, Integer> entry = sortedEntries.get(i);
            result[i][0] = entry.getKey();   // ubicación
            result[i][1] = entry.getValue(); // veces desocupada
        }
        
        return result;
    }
    
    /**
     * REQUISITO 13: Consulta ganancias de cada robot en cada movimiento
     * @param robotIndex índice del robot (0, 1, 2, ...)
     * @return lista de MovementProfit con historial completo
     */
    public List<MovementProfit> getRobotMovementProfits(int robotIndex) {
        return robotMovementProfits.getOrDefault(robotIndex, new ArrayList<>());
    }
    
    /**
     * Versión simplificada que retorna array para compatibilidad
     * @param robotIndex índice del robot
     * @return array [movimiento][0=from, 1=to, 2=profit] 
     */
    public int[][] getRobotProfitHistory(int robotIndex) {
        List<MovementProfit> movements = getRobotMovementProfits(robotIndex);
        
        int[][] result = new int[movements.size()][3];
        for (int i = 0; i < movements.size(); i++) {
            MovementProfit move = movements.get(i);
            result[i][0] = move.fromLocation;
            result[i][1] = move.toLocation;
            result[i][2] = move.profitGained;
        }
        
        return result;
    }
    
    /**
     * Obtiene el robot con mayor ganancia total para efectos visuales
     */
    public int getTopRobotIndex() {
        int topRobotIndex = -1;
        int maxProfit = -1;
        
        for (int i = 0; i < robots.size(); i++) {
            int robotTotalProfit = 0;
            for (MovementProfit movement : getRobotMovementProfits(i)) {
                robotTotalProfit += movement.profitGained;
            }
            
            if (robotTotalProfit > maxProfit) {
                maxProfit = robotTotalProfit;
                topRobotIndex = i;
            }
        }
        
        return topRobotIndex;
    }

    // ============ MÉTODOS AUXILIARES ============
    
    private boolean isValidLocation(int location) {
        return location >= 0 && location < length;
    }

    private Store findStoreAt(int location) {
        for (Store store : stores) {
            if (store.getLocation() == location) {
                return store;
            }
        }
        return null;
    }

    private Robot findFirstRobotAt(int location) {
        for (Robot robot : robots) {
            if (robot.getLocation() == location) {
                return robot;
            }
        }
        return null;
    }

    private int getMaxPossibleProfit() {
        int max = 0;
        for (Store store : stores) {
            max += store.getTenges();
        }
        return Math.max(max, 1);
    }

    private void updateProfitDisplay() {
        display.updateProfit(totalProfit, getMaxPossibleProfit());
    }

    private void showError(String message) {
        display.showError(message);
    }

    // ============ CLASES AUXILIARES ============

    /**
     * Store vacía para simular tienda desocupada
     */
    private static class StoreEmpty extends Store {
        public StoreEmpty(int location) {
            super(location, 0);
        }
    }

    private static class StoreState {
        final int location;
        final int tenges;
        
        StoreState(int location, int tenges) {
            this.location = location;
            this.tenges = tenges;
        }
    }

    private static class RobotState {
        final int id;
        final int location;
        
        RobotState(int id, int location) {
            this.id = id;
            this.location = location;
        }
    }

    private static class RobotInfo {
        final int location;
        final int id;
        
        RobotInfo(int location, int id) {
            this.location = location;
            this.id = id;
        }
    }
    
    /**
     * NUEVO: Clase para tracking de movimientos y ganancias
     */
    public static class MovementProfit {
        public final int fromLocation;
        public final int toLocation;
        public final int distance;
        public final int profitGained;
        public final boolean isAIMovement;
        public final long timestamp;
        
        public MovementProfit(int from, int to, int distance, int profit, boolean isAI) {
            this.fromLocation = from;
            this.toLocation = to;
            this.distance = distance;
            this.profitGained = profit;
            this.isAIMovement = isAI;
            this.timestamp = System.currentTimeMillis();
        }
        
        @Override
        public String toString() {
            return String.format("Move from %d to %d (distance %d): +%d tenges %s", 
                               fromLocation, toLocation, distance, profitGained,
                               isAIMovement ? "[AI]" : "[Manual]");
        }
    }
    
    /**
     * NUEVO: Clase para resultado de cálculo de mejor movimiento
     */
    private static class BestMove {
        boolean isValid = false;
        int distance = 0;
        int targetLocation = 0;
        int expectedProfit = 0;
        double score = 0.0;
    }

    // ============ MÉTODO MAIN ACTUALIZADO ============
    
    public static void main(String[] args) {
        System.out.println("=== SILK ROAD SIMULATOR - VERSIÓN AVANZADA ===\n");
        
        // Demonstración de entrada de maratón (Requisito 10)
        System.out.println("--- REQUISITO 10: Entrada de Maratón ---");
        String marathonInput = "length=15;stores=3:150,8:200,12:100;robots=0,5";
        SilkRoad road = new SilkRoad(marathonInput);
        road.makeVisible();
        
        System.out.println("Configuración inicial:");
        printStores(road);
        printRobots(road);
        
        // Demonstración de IA (Requisito 11)
        System.out.println("\n--- REQUISITO 11: IA de Robots ---");
        road.enableAIMovement(true);
        road.executeAIMovements();
        
        System.out.println("Después de movimientos IA:");
        System.out.println("Ganancia total: " + road.profit());
        
        // Demonstración de contadores (Requisito 12)
        System.out.println("\n--- REQUISITO 12: Contador de Tiendas Desocupadas ---");
        int[][] emptyCounts = road.getStoreEmptyCount();
        for (int[] count : emptyCounts) {
            System.out.println("Tienda ubicación " + count[0] + " desocupada " + count[1] + " veces");
        }
        
        // Demonstración de historial (Requisito 13)
        System.out.println("\n--- REQUISITO 13: Historial de Ganancias ---");
        for (int i = 0; i < road.robots().length; i++) {
            System.out.println("Robot " + i + " historial:");
            List<MovementProfit> history = road.getRobotMovementProfits(i);
            for (MovementProfit move : history) {
                System.out.println("  " + move);
            }
        }
        
        System.out.println("\nSimulador avanzado funcionando correctamente!");
        System.out.println("Robot top performer: " + road.getTopRobotIndex());
    }
    
    private static void printStores(SilkRoad road) {
        int[][] stores = road.stores();
        System.out.println("Tiendas:");
        for (int[] store : stores) {
            System.out.println("  Ubicación " + store[0] + ": " + store[1] + " tenges");
        }
    }
    
    private static void printRobots(SilkRoad road) {
        int[][] robots = road.robots();
        System.out.println("Robots:");
        for (int[] robot : robots) {
            System.out.println("  Robot " + robot[1] + " en ubicación " + robot[0]);
        }
    }
    
        /**
     * NUEVO: Actualiza el robot top performer en el display
     * Debe llamarse después de operaciones que cambien las ganancias
     */
    private void updateTopRobotDisplay() {
        int newTopRobot = getTopRobotIndex();
        display.setTopRobot(newTopRobot);
        }
}