import java.awt.Color;

/**
 * Store.java - Tienda con estados visuales diferenciados.
 * Versión avanzada que distingue tiendas llenas vs desocupadas.
 * @author TU_NOMBRE
 * @version REQUISITOS_AVANZADOS
 */
public class Store {
    private final int location;
    private final int tenges;
    private final Color color;
    private boolean isEmpty; // NUEVO: Estado para distinguir tiendas vacías
    
    public Store(int location, int tenges) {
        this.location = location;
        this.tenges = tenges;
        this.isEmpty = (tenges == 0);
        this.color = generateStoreColor();
    }
    
    /**
     * NUEVO: Genera color diferenciado según estado de la tienda
     */
    private Color generateStoreColor() {
        if (isEmpty) {
            // Tiendas desocupadas: color gris apagado
            return Color.LIGHT_GRAY;
        } else {
            // Tiendas con dinero: verde brillante (color original)
            return Color.getHSBColor(0.33f, 1f, 1f);
        }
    }
    
    // Métodos originales
    public int getLocation() { return location; }
    public int getTenges() { return tenges; }
    public Color getColor() { return color; }
    
    // NUEVO: Métodos para manejo de estado vacío
    public boolean isEmpty() { return isEmpty; }
    
    /**
     * Marca la tienda como desocupada (para efectos visuales)
     */
    public void markAsEmpty() {
        isEmpty = true;
    }
    
    /**
     * Obtiene descripción del estado para debugging
     */
    public String getStatusDescription() {
        if (isEmpty) {
            return "EMPTY store at location " + location;
        } else {
            return "ACTIVE store at location " + location + " with " + tenges + " tenges";
        }
    }
    
    @Override
    public String toString() {
        return getStatusDescription();
    }
}